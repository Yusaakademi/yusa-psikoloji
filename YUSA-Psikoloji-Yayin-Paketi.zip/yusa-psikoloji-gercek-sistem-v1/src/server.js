import express from "express";
import path from "path";
import {fileURLToPath} from "url";
import Database from "better-sqlite3";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import cookieParser from "cookie-parser";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import multer from "multer";
import nodemailer from "nodemailer";
import fs from "fs";

const __dirname=path.dirname(fileURLToPath(import.meta.url));
const ROOT=path.join(__dirname,"..");
const DATA_DIR=process.env.DATA_DIR || path.join(ROOT,"data");
fs.mkdirSync(DATA_DIR,{recursive:true});
const db=new Database(process.env.DB_PATH || path.join(DATA_DIR,"yusa.db"));
db.pragma("journal_mode=WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS admins(id INTEGER PRIMARY KEY,email TEXT UNIQUE,password_hash TEXT NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS pages(id INTEGER PRIMARY KEY,slug TEXT UNIQUE,title TEXT NOT NULL,meta_title TEXT,meta_description TEXT,content_json TEXT NOT NULL,published INTEGER DEFAULT 1,updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS articles(id INTEGER PRIMARY KEY,slug TEXT UNIQUE,title TEXT NOT NULL,excerpt TEXT,body TEXT NOT NULL,category TEXT,reading_minutes INTEGER DEFAULT 5,cover TEXT,meta_title TEXT,meta_description TEXT,published INTEGER DEFAULT 0,created_at TEXT DEFAULT CURRENT_TIMESTAMP,updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS availability(id INTEGER PRIMARY KEY,start_at TEXT NOT NULL,end_at TEXT NOT NULL,mode TEXT DEFAULT 'both',status TEXT DEFAULT 'open');
CREATE TABLE IF NOT EXISTS appointments(id INTEGER PRIMARY KEY,name TEXT NOT NULL,email TEXT NOT NULL,phone TEXT,mode TEXT NOT NULL,start_at TEXT NOT NULL,note TEXT,status TEXT DEFAULT 'pending',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT NOT NULL);
`);
const getSetting=k=>db.prepare("SELECT value FROM settings WHERE key=?").get(k)?.value;
const setSetting=(k,v)=>db.prepare("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value").run(k,String(v));

const email=process.env.ADMIN_EMAIL;
const pass=process.env.ADMIN_PASSWORD;
if(process.env.NODE_ENV === "production" && (!email || !pass || !process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32)) {
  throw new Error("Production için ADMIN_EMAIL, güçlü ADMIN_PASSWORD ve en az 32 karakterli JWT_SECRET zorunludur.");
}
if(!db.prepare("SELECT id FROM admins LIMIT 1").get() && email && pass){
  db.prepare("INSERT INTO admins(email,password_hash) VALUES(?,?)").run(email,bcrypt.hashSync(pass,12));
}
if(!getSetting("site_name")) setSetting("site_name","YUSA Psikoloji");
if(process.env.SITE_URL) setSetting("site_url",process.env.SITE_URL.replace(/\/$/,""));
if(!getSetting("site_url")) setSetting("site_url","http://localhost:3000");

const app=express();
app.use(helmet({contentSecurityPolicy:false}));
app.use(express.json({limit:"2mb"})); app.use(express.urlencoded({extended:true}));
app.use(cookieParser());
app.use(express.static(path.join(ROOT,"public")));
app.use("/uploads", express.static(UPLOAD_DIR));
const loginLimiter=rateLimit({windowMs:15*60*1000,max:10,standardHeaders:true,legacyHeaders:false});
const UPLOAD_DIR=path.join(DATA_DIR,"uploads");
fs.mkdirSync(UPLOAD_DIR,{recursive:true});
const upload=multer({dest:UPLOAD_DIR,limits:{fileSize:5*1024*1024},fileFilter:(req,file,cb)=>{
  const ok=["image/jpeg","image/png","image/webp"].includes(file.mimetype);
  cb(ok?null:new Error("Yalnızca JPG, PNG veya WEBP görsel yükleyebilirsiniz."),ok);
}});

function sign(admin){return jwt.sign({id:admin.id,email:admin.email},""+(process.env.JWT_SECRET||"dev-secret-change-me"),{expiresIn:"8h"})}
function auth(req,res,next){try{const t=req.cookies.yusa_admin; if(!t) return res.status(401).json({error:"Oturum gerekli"}); req.admin=jwt.verify(t,process.env.JWT_SECRET||"dev-secret-change-me"); next()}catch{return res.status(401).json({error:"Oturum süresi doldu"})}}
function slugify(s){return s.toString().toLowerCase().normalize("NFKD").replace(/[\u0300-\u036f]/g,"").replace(/ı/g,"i").replace(/ğ/g,"g").replace(/ü/g,"u").replace(/ş/g,"s").replace(/ö/g,"o").replace(/ç/g,"c").replace(/[^a-z0-9]+/g,"-").replace(/(^-|-$)/g,"")}
function sendMail(to,subject,text){
  if(!process.env.SMTP_HOST) return Promise.resolve(false);
  const tr=nodemailer.createTransport({host:process.env.SMTP_HOST,port:+(process.env.SMTP_PORT||587),secure:false,auth:{user:process.env.SMTP_USER,pass:process.env.SMTP_PASS}});
  return tr.sendMail({from:process.env.MAIL_FROM||process.env.SMTP_USER,to,subject,text}).then(()=>true).catch(()=>false);
}

/* Auth */
app.post("/api/admin/login",loginLimiter,(req,res)=>{
  const a=db.prepare("SELECT * FROM admins WHERE email=?").get(req.body.email||"");
  if(!a||!bcrypt.compareSync(req.body.password||"",a.password_hash)) return res.status(401).json({error:"E-posta veya parola hatalı"});
  res.cookie("yusa_admin",sign(a),{httpOnly:true,sameSite:"lax",secure:process.env.NODE_ENV==="production",maxAge:8*60*60*1000});
  res.json({ok:true});
});
app.post("/api/admin/logout",(req,res)=>{res.clearCookie("yusa_admin");res.json({ok:true})});
app.get("/api/admin/me",auth,(req,res)=>res.json({email:req.admin.email}));

/* Public */
app.get("/api/public/site",(req,res)=>{
  const pages=db.prepare("SELECT id,slug,title,meta_title,meta_description,content_json FROM pages WHERE published=1 ORDER BY id").all();
  const articles=db.prepare("SELECT id,slug,title,excerpt,body,category,reading_minutes,cover,meta_title,meta_description,created_at FROM articles WHERE published=1 ORDER BY created_at DESC").all();
  res.json({settings:Object.fromEntries(db.prepare("SELECT key,value FROM settings").all().map(x=>[x.key,x.value])),pages,articles});
});
app.get("/api/public/availability",(req,res)=>{
  const rows=db.prepare("SELECT id,start_at,end_at,mode FROM availability WHERE status='open' AND start_at>=? ORDER BY start_at").all(new Date().toISOString());
  res.json(rows);
});
const bookingLimiter=rateLimit({windowMs:60*60*1000,max:8,standardHeaders:true,legacyHeaders:false});
app.post("/api/public/appointments",bookingLimiter,async(req,res)=>{
  const {name,email,phone,mode,note,availability_id}=req.body;
  if(!name?.trim()||!email?.trim()||!mode||!availability_id||req.body.consent!==true) return res.status(400).json({error:"Lütfen zorunlu alanları ve aydınlatma onayını tamamlayın."});
  if(!/^\S+@\S+\.\S+$/.test(email)) return res.status(400).json({error:"Geçerli bir e-posta adresi girin."});
  const create=db.transaction(()=>{
    const slot=db.prepare("SELECT * FROM availability WHERE id=? AND status='open'").get(availability_id);
    if(!slot || (slot.mode!=="both" && slot.mode!==mode)) throw new Error("SLOT_UNAVAILABLE");
    if(new Date(slot.start_at)<=new Date()) throw new Error("SLOT_UNAVAILABLE");
    const r=db.prepare("INSERT INTO appointments(name,email,phone,mode,start_at,note) VALUES(?,?,?,?,?,?)").run(name.trim(),email.trim(),phone||"",mode,slot.start_at,(note||"").slice(0,500));
    const changed=db.prepare("UPDATE availability SET status='booked' WHERE id=? AND status='open'").run(slot.id);
    if(changed.changes!==1) throw new Error("SLOT_UNAVAILABLE");
    return {id:r.lastInsertRowid,start_at:slot.start_at};
  });
  let created;
  try { created=create(); } catch(e) { if(e.message==="SLOT_UNAVAILABLE") return res.status(409).json({error:"Bu saat artık uygun değil. Lütfen başka bir saat seçin."}); throw e; }
  const text=`Yeni YUSA Psikoloji randevu talebi\n\n${name}\n${email}\n${phone||""}\n${mode}\n${created.start_at}\n\n${note||""}`;
  await sendMail(process.env.ADMIN_EMAIL||email,"Yeni randevu talebi",text);
  await sendMail(email,"YUSA Psikoloji — Randevu talebiniz alındı",`Merhaba ${name}, ${created.start_at} için randevu talebiniz alınmıştır. Kesinleşme bilgisi ayrıca paylaşılacaktır.`);
  res.status(201).json({ok:true,id:created.id});
});

/* Admin CRUD */
app.get("/api/admin/dashboard",auth,(req,res)=>{
  res.json({
    articles:db.prepare("SELECT COUNT(*) n FROM articles").get().n,
    published:db.prepare("SELECT COUNT(*) n FROM articles WHERE published=1").get().n,
    appointments:db.prepare("SELECT COUNT(*) n FROM appointments WHERE status IN ('pending','confirmed')").get().n,
    availability:db.prepare("SELECT COUNT(*) n FROM availability WHERE status='open'").get().n
  })
});
app.get("/api/admin/pages",auth,(req,res)=>res.json(db.prepare("SELECT * FROM pages ORDER BY id").all()));
app.post("/api/admin/pages",auth,(req,res)=>{
  const slug=req.body.slug||slugify(req.body.title||"sayfa");
  const r=db.prepare("INSERT INTO pages(slug,title,meta_title,meta_description,content_json,published) VALUES(?,?,?,?,?,?)").run(slug,req.body.title,req.body.meta_title||"",req.body.meta_description||"",JSON.stringify(req.body.content||[]),req.body.published?1:0);
  res.json({id:r.lastInsertRowid,slug});
});
app.put("/api/admin/pages/:id",auth,(req,res)=>{
  db.prepare("UPDATE pages SET title=?,meta_title=?,meta_description=?,content_json=?,published=?,updated_at=CURRENT_TIMESTAMP WHERE id=?").run(req.body.title,req.body.meta_title||"",req.body.meta_description||"",JSON.stringify(req.body.content||[]),req.body.published?1:0,req.params.id);
  res.json({ok:true});
});
app.delete("/api/admin/pages/:id",auth,(req,res)=>{db.prepare("DELETE FROM pages WHERE id=?").run(req.params.id);res.json({ok:true})});

app.get("/api/admin/articles",auth,(req,res)=>res.json(db.prepare("SELECT * FROM articles ORDER BY updated_at DESC").all()));
app.post("/api/admin/articles",auth,(req,res)=>{
  const slug=req.body.slug||slugify(req.body.title||"makale");
  const r=db.prepare("INSERT INTO articles(slug,title,excerpt,body,category,reading_minutes,cover,meta_title,meta_description,published) VALUES(?,?,?,?,?,?,?,?,?,?)").run(slug,req.body.title,req.body.excerpt||"",req.body.body||"",req.body.category||"Psikoloji",+(req.body.reading_minutes||5),req.body.cover||"",req.body.meta_title||req.body.title,req.body.meta_description||req.body.excerpt||"",req.body.published?1:0);
  res.json({id:r.lastInsertRowid,slug});
});
app.put("/api/admin/articles/:id",auth,(req,res)=>{
  db.prepare("UPDATE articles SET title=?,excerpt=?,body=?,category=?,reading_minutes=?,cover=?,meta_title=?,meta_description=?,published=?,updated_at=CURRENT_TIMESTAMP WHERE id=?").run(req.body.title,req.body.excerpt||"",req.body.body||"",req.body.category||"Psikoloji",+(req.body.reading_minutes||5),req.body.cover||"",req.body.meta_title||"",req.body.meta_description||"",req.body.published?1:0,req.params.id);
  res.json({ok:true});
});
app.delete("/api/admin/articles/:id",auth,(req,res)=>{db.prepare("DELETE FROM articles WHERE id=?").run(req.params.id);res.json({ok:true})});

app.get("/api/admin/availability",auth,(req,res)=>res.json(db.prepare("SELECT * FROM availability ORDER BY start_at").all()));
app.post("/api/admin/availability",auth,(req,res)=>{
  if(!req.body.start_at||!req.body.end_at) return res.status(400).json({error:"Tarih ve saat gerekli"});
  const r=db.prepare("INSERT INTO availability(start_at,end_at,mode,status) VALUES(?,?,?,'open')").run(req.body.start_at,req.body.end_at,req.body.mode||"both");
  res.json({id:r.lastInsertRowid});
});
app.delete("/api/admin/availability/:id",auth,(req,res)=>{db.prepare("DELETE FROM availability WHERE id=?").run(req.params.id);res.json({ok:true})});

app.get("/api/admin/appointments",auth,(req,res)=>res.json(db.prepare("SELECT * FROM appointments ORDER BY start_at DESC").all()));
app.patch("/api/admin/appointments/:id",auth,(req,res)=>{db.prepare("UPDATE appointments SET status=? WHERE id=?").run(req.body.status,req.params.id);res.json({ok:true})});

app.get("/api/admin/settings",auth,(req,res)=>res.json(Object.fromEntries(db.prepare("SELECT key,value FROM settings").all().map(x=>[x.key,x.value]))));
app.put("/api/admin/settings",auth,(req,res)=>{for(const [k,v] of Object.entries(req.body)) setSetting(k,v);res.json({ok:true})});
app.post("/api/admin/upload",auth,upload.single("file"),(req,res)=>res.json({url:"/uploads/"+req.file.filename,original:req.file.originalname}));

app.get("/health",(req,res)=>res.json({ok:true,service:"yusa-psikoloji"}));

/* sitemap + robots */
app.get("/sitemap.xml",(req,res)=>{
  const base=getSetting("site_url")||`${req.protocol}://${req.get("host")}`;
  const pages=db.prepare("SELECT slug,updated_at FROM pages WHERE published=1").all();
  const articles=db.prepare("SELECT slug,updated_at FROM articles WHERE published=1").all();
  const urls=[...pages.map(x=>`/${x.slug}`),...articles.map(x=>`/dergi/${x.slug}`),"/"];
  res.type("application/xml").send(`<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${urls.map(u=>`<url><loc>${base}${u}</loc></url>`).join("")}</urlset>`);
});
app.get("/robots.txt",(req,res)=>res.type("text/plain").send(`User-agent: *\nAllow: /\nSitemap: ${(getSetting("site_url")||`${req.protocol}://${req.get("host")}`)}/sitemap.xml`));

function esc(v=""){return String(v).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
app.get("/dergi/:slug",(req,res,next)=>{
  const a=db.prepare("SELECT * FROM articles WHERE slug=? AND published=1").get(req.params.slug);
  if(!a) return next();
  const html=`<!doctype html><html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(a.meta_title||a.title)} | YUSA Psikoloji</title><meta name="description" content="${esc(a.meta_description||a.excerpt||"")}"><link rel="canonical" href="${esc(getSetting("site_url")||"")}/dergi/${esc(a.slug)}"><link rel="stylesheet" href="/style.css"></head><body><header><div class="nav wrap"><a class="logo" href="/">YUSA <small>PSİKOLOJİ</small></a><nav><a href="/#about">Hakkımda</a><a href="/#areas">Çalışma Alanları</a><a href="/#journal">Dergi</a><a href="/#booking">Randevu</a></nav></div></header><main><article class="wrap article-detail"><p class="eyebrow">YUSA PSİKOLOJİ DERGİSİ · ${esc(a.category||"Psikoloji")} · ${Number(a.reading_minutes)||5} DK OKUMA</p><h1>${esc(a.title)}</h1><p class="article-lead">${esc(a.excerpt||"")}</p><div class="article-body">${String(a.body||"").split(/\n{2,}/).map(p=>`<p>${esc(p).replace(/\n/g,"<br>")}</p>`).join("")}</div><a class="btn" href="/#booking">Randevu hakkında bilgi alın</a></article></main><footer><div class="wrap">YUSA Psikoloji · Psikolog Ömer Yusuf Şahin</div></footer></body></html>`;
  res.type("html").send(html);
});
app.get("/admin",(_,res)=>res.sendFile(path.join(ROOT,"public","admin.html")));
app.get("*",(req,res)=>res.sendFile(path.join(ROOT,"public","index.html")));

const port=process.env.PORT||3000;
app.listen(port,()=>console.log(`YUSA Psikoloji: http://localhost:${port}`));
