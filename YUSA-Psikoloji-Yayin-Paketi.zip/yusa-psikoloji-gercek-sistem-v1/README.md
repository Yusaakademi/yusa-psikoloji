# YUSA Psikoloji — canlıya hazırlık paketi

Node.js + Express + SQLite tabanlı web uygulaması. Yönetim paneli `/admin` adresindedir. Ziyaretçiler üyelik oluşturmadan, yönetici tarafından açılan müsaitlik saatlerinden randevu talebi gönderebilir.

## Önce bilinmesi gerekenler

Bu paket, canlıya taşınabilir bir uygulama temelidir; ancak alan adı, hosting hesabı, yönetici parolası, kalıcı disk, e-posta sağlayıcısı ve KVKK metinleri hesap sahibi tarafından yapılandırılmadan kamuya açılmamalıdır. E-posta gönderimi SMTP bilgileri girilene kadar çalışmaz. Randevu talebi otomatik olarak kesinleşmez; yönetici panelinden onaylanmalıdır.

## Yerelde çalıştırma

1. Node.js 20 veya üzerini kurun.
2. Bu klasörde terminal açın.
3. `npm install` çalıştırın.
4. `.env.example` dosyasını `.env` olarak kopyalayıp değerleri düzenleyin.
5. `npm start` çalıştırın.
6. `http://localhost:3000` ana site, `http://localhost:3000/admin` yönetim panelidir.

Üretimde `.env` dosyası yerine hosting sağlayıcısının Variables/Environment alanını kullanın. `ADMIN_EMAIL`, `ADMIN_PASSWORD` ve en az 32 karakterlik `JWT_SECRET` zorunludur. İlk açılışta yönetici hesabı bu bilgilerle oluşturulur. Daha sonra parolayı hosting değişkenlerinden güncellemek tek başına mevcut hash'i değiştirmez; ilk kurulumda doğru parolayı seçin ve güvenli yerde saklayın.

## Önerilen kolay yayınlama: Railway + GitHub

1. GitHub'da yeni, **Private** bir repository oluşturun: `yusa-psikoloji`.
2. ZIP'i bilgisayarda açın; içindeki proje dosyalarını repository'nin köküne yükleyin (`package.json` kökte görünmeli). ZIP dosyasını tek başına yüklemeyin.
3. Railway hesabı açın ve `New Project` → `Deploy from GitHub repo` ile bu repository'yi seçin.
4. Railway'de uygulama servisine bir Volume ekleyin ve mount path'i `/app/data` yapın. SQLite veritabanı ve yüklenen görseller bu kalıcı diskte saklanır.
5. Uygulama servisinin Variables alanına `.env.example` içindeki değişkenleri girin. `DATA_DIR=/app/data` olmalı. `ADMIN_EMAIL`, `ADMIN_PASSWORD` ve `JWT_SECRET` için kendi güçlü değerlerinizi kullanın.
6. Deploy tamamlanınca Settings → Networking → Generate Domain ile geçici `*.up.railway.app` adresi üretin.
7. Siteyi ve `/admin` panelini test edin. Admin'den birkaç müsait saat açıp deneme randevusu gönderin; ardından deneme kayıtlarını silin.
8. Alan adınızı satın aldıktan sonra Railway Settings → Networking → Custom Domain bölümüne ekleyin ve Railway'in gösterdiği CNAME + TXT DNS kayıtlarını alan adı sağlayıcınıza girin. HTTPS sertifikası Railway tarafından sağlanır.
9. SMTP bilgilerini girip e-posta testini yapın. SMTP olmadan otomatik e-posta bildirimi gönderilmez.

## Yayına almadan önce zorunlu kontrol listesi

- [ ] Admin parolası ve JWT_SECRET benzersiz, güçlü ve gizli
- [ ] Railway Volume `/app/data` mount edildi; yeniden deploy sonrası randevu ve görseller korunuyor
- [ ] Gerçek domain, DNS ve HTTPS doğrulandı
- [ ] SMTP üzerinden hem yönetici hem başvuru sahibine e-posta testi yapıldı
- [ ] Yönetici müsaitlik açtı; çakışan iki randevu testi yapıldı
- [ ] KVKK aydınlatma metni, veri sorumlusu/iletişim bilgileri, saklama-imha süreleri ve çerez açıklaması hukukî incelemeden geçirildi
- [ ] Randevu formu yalnızca gerekli verileri topluyor; danışanlardan sağlık/özel nitelikli bilgi istemiyor
- [ ] Site içeriği, mesleki unvan, eğitim ve çalışma alanları gerçek bilgilerle son kez doğrulandı
- [ ] Google Search Console ve sitemap alan adı doğrulamasından sonra kuruldu
- [ ] Yedekleme ve geri yükleme testi yapıldı

## Güvenlik ve veri notu

Randevu verileri ve yönetici hesabı kişisel veri içerir. Bu paketi canlıya almadan önce KVKK yükümlülükleri, erişim yetkileri, veri saklama süresi, yedekleme ve olay müdahalesi bir uzmanla gözden geçirilmelidir. Gerçek danışan vaka notlarını bu web formunda toplamayın.

## Dosyalar

- `public/index.html`: ziyaretçi sitesi
- `public/style.css`: masaüstü ve mobil tasarım
- `public/admin.html`: yönetim paneli
- `src/server.js`: API, oturum, randevu, makale ve sayfa yönetimi
- `public/yusa-logo.jpeg`: sağlanan YUSA logosu
- `public/omer-yusuf-sahin.jpeg`: sağlanan portre fotoğrafı
